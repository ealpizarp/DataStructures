#include "DNode.h"

DNode::DNode()
{
    //ctor
}

DNode::~DNode()
{
    //dtor
}
