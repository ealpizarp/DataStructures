#include "ewfew.h"

ewfew::ewfew()
{
    //ctor
}

ewfew::~ewfew()
{
    //dtor
}
