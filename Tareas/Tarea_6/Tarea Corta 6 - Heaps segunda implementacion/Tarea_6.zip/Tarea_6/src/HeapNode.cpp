#include "HeapNode.h"

HeapNode::HeapNode()
{
    //ctor
}

HeapNode::~HeapNode()
{
    //dtor
}
