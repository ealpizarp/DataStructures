#ifndef HEAPNODE_H
#define HEAPNODE_H

template <typename Key, typename E>
class HeapNode
{
private:
    Key key;
    E element;

public:
    HeapNode() {}
    ~HeapNode() {}
    Key getKey() {
        return key;
    }
    void setKey(Key pKey) {
        key = pKey;
    }
    E getElement() {
        return element;
    }
    void setElement(E pElement) {
        element = pElement;
    }
};

#endif // HEAPNODE_H
