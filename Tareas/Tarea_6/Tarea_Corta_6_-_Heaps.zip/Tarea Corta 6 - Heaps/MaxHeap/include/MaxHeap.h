#ifndef MAXHEAP_H
#define MAXHEAP_H

#include <stdexcept>

using namespace std;

template <typename E>
class MaxHeap {
private:
    int maxSize;
    int size;
    E* elements;

    int leftChild(int pos) {
        return 2 * pos + 1;
    }
    int rightChild(int pos) {
        return 2 * pos + 2;
    }
    int parent(int pos) {
        if (pos == 0) {
            return -1;
        }
        return (pos - 1) / 2;
    }
    int isLeaf(int pos) throw (runtime_error) {
        if ((pos >= size) || (pos < 0)) {
            throw runtime_error("Position out of range.");
        }
        return leftChild(pos) >= size;
    }
    void swap(int pos1, int pos2) {
        throw runtime_error("swap method not implemented.");
    }
    void siftUp(int pos) {
        throw runtime_error("siftUp method not implemented.");
    }
    void siftDown(int pos) {
        throw runtime_error("siftDown method not implemented.");
    }
    int greaterChild(int i) {
        throw runtime_error("greaterChild method not implemented.");
    }

public:
    MaxHeap(int maxSize = 1024) {
        this->maxSize = maxSize;
        size = 0;
        elements = new E[maxSize];
    }
    ~MaxHeap() {
        delete [] elements;
    }
    void insert(E element) throw (runtime_error) {
        throw runtime_error("insert method not implemented.");
    }
    E removeFirst() throw (runtime_error) {
        throw runtime_error("removeFirst method not implemented.");
    }
    E remove(int pos) throw (runtime_error) {
        throw runtime_error("greaterChild method not implemented.");
    }
    int getSize() {
        return size;
    }
};

#endif // MAXHEAP_H
