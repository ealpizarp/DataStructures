#include <iostream>
#include "include\MaxHeap.h"
#include <string>

using namespace std;

int main()
{
    cout << "Such emptyness." << endl;
    return 0;
}
