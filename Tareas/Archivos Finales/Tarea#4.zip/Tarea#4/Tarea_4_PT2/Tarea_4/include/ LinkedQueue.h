#ifndef  LINKEDQUEUE_H
#define  LINKEDQUEUE_H


class  LinkedQueue
{
    public:
         LinkedQueue() {}
        virtual ~ LinkedQueue() {}

    protected:

    private:
};

#endif //  LINKEDQUEUE_H
