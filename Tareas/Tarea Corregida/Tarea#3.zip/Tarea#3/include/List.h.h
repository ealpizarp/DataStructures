#ifndef LIST_H_H
#define LIST_H_H


class List.h
{
    public:
        List.h() {}
        virtual ~List.h() {}

    protected:

    private:
};

#endif // LIST_H_H
