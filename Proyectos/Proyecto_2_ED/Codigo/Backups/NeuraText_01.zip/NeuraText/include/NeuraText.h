#ifndef NEURATEXT_H
#define NEURATEXT_H

#include<fstream>
#include <iostream>
#include<stdexcept>

#include "AVLTreeDictionary.h"
#include "SplayTree.h"
#include "Trie.h"

using std::string;

using std:: runtime_error;

using std::fstream;

class NeuraText {

private:
    AVLTreeDictionary<int, string>* MegaEstructura = new AVLTreeDictionary<int, string>();

    Trie* trie = new Trie();

    List<string>* MostFrequentWords;

    SplayTree<string>* StopWords = new SplayTree<string>();

    void cargarPalabrasIgnorarAux(string nombre) {
        string linea;
        std::ifstream archivo(nombre);
        if (archivo.is_open()) {
            std::cout<< "Cargando palabras a ignorar..." << std::endl;
            while (archivo.good()) {
                getline(archivo, linea);
                StopWords->insert(linea);
            }
        archivo.close();
        }
        else {
            throw runtime_error("File not found or cannot be opened!");
        }
    }


    void cargarArchivoAux(string nombre) {
        string linea;
        std::ifstream archivo(nombre);
        int contador = 0;
        if (archivo.is_open()) {
            std::cout<< "Analizando el archivo.." << std::endl;
            while (archivo.good()) {
                getline(archivo, linea);
                MegaEstructura->insert(contador,linea);
                contador++;
            }
        archivo.close();
        }
        else {
            throw runtime_error("File not found or cannot be opened!");
        }
        string temp;
        int numLinea = 0;
        for (int i = 0; i < MegaEstructura->getSize(); i++) {
            temp = MegaEstructura->getValue(i);
            string word = "";
            for (unsigned int i = 0; i < temp.size(); i++) {
                if(isalpha(temp[i]) && !isspace(temp[i])) {
                    word = word + temp[i];
                }
                if(isspace(temp[i]) || i == temp.size() -1) {
                    bool contains = trie->containsWord(word);
                    if (word != "" && !contains){
                    trie->insert(word);
                    }
                    if(contains) {
                        trie->increaseWordFrequency(word);
                    }
                 word = "";
                }
                if (i == temp.size()-1) {
                    numLinea++;
                }
            }
        }
        std::cout<<"Tamano del trie: " << trie->getSize() <<std::endl;
        std::cout << "Archivo analizado exitosamente"<< std::endl;
    }

public:
    NeuraText() {}

    ~NeuraText() {}

    void cargarArchivo(string nombre) {
        cargarArchivoAux(nombre);

    }

    void cargarPalabrasIgnorar(string nombre) {
        cargarPalabrasIgnorarAux(nombre);
        StopWords->inOrder();
    }

    void mostrarPalabrasTrie() {
        List<string>* palabras;
        palabras = trie->getMatches("");
        for (palabras->goToStart(); !palabras->atEnd(); palabras->next()) {
            std::cout << palabras->getElement() << std::endl;
        }
        std::cout<<std::endl;
        delete palabras;
    }

    void mostrarPalabrasPorProfundidad(int profundidad) {
        List<string>* palabras;
        palabras = trie->getDepthWords(profundidad);
        for(palabras->goToStart(); !palabras->atEnd(); palabras->next()) {
            std::cout<<palabras->getElement() <<std::endl;
        }
        delete palabras;
    }

    void CargarPalabrasMasUtilizadas() {
        MostFrequentWords = trie->getMostFrequentWords();
    }

    void palabrasMasUtilizadas(int rango) {
        MostFrequentWords->goToStart();
        for (int i = 0; i < rango; i++) {
            std::cout<< MostFrequentWords->getElement() << endl;
            MostFrequentWords->next();
        }
    }



};

#endif // NEURATEXT_H
