//#include"conmanip.h"
#include"windows.h"
#include"NeuraText.h"
#include"Trie.h"
using namespace std;

int main()
{
    // Aqui vamos a configurar la consola de salida para que tenga un tamano optimo para el funcionamiento del programa
    /*
    conmanip::console_out_context ctxout;
    conmanip::console_out conout(ctxout);
    conout.settitle("Neura Text");
    SetConsoleOutputCP(65001);
    HWND console = GetConsoleWindow();
    RECT r;
    GetWindowRect(console, &r);
    */

    SetConsoleOutputCP(CP_UTF8);

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    NeuraText text;
    //setlocale(LC_ALL, "");
    text.cargarArchivo("Quijote.txt");
    text.mostrarPalabrasPorProfundidad(1);
    cout<<"Estas son las palabras mas utilizadas en el texto"<<endl;
    text.cargarPalabrasIgnorar("Ignore.txt");
    text.CargarPalabrasMasUtilizadas();
    //text.palabrasMasUtilizadas(50);
    //system("pause");
    //text.mostrarPalabrasTrie();
    return 0;
}
